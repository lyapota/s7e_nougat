<@center><b><#selectbg_g>Requirements</#></b>
You need to be on a close to Stock SG Nougat ROM to flash this kernel. 
<#c00>If you are not willing to agree with these conditions, do not continue the installation proccess.</#>

<b><#selectbg_g>Would you like to continue?</#></b>
